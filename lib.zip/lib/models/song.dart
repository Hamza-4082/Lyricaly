// lib/models/song.dart
class Song {
  final String id;
  final String title;
  final String artist;
  final String? album;

  // One of these sources will be used:
  final String? audioUrl;    // remote URL (optional)
  final String? assetAudio;  // bundled asset path (e.g., assets/audio/xxx.mp3)
  final String? filePath;    // local file on device (optional)

  // Artwork (either one)
  final String? imageUrl;    // remote image (optional)
  final String? assetImage;  // bundled artwork (e.g., assets/images/xxx.jpg)

  const Song({
    required this.id,
    required this.title,
    required this.artist,
    this.album,
    this.audioUrl,
    this.assetAudio,
    this.filePath,
    this.imageUrl,
    this.assetImage,
  });

  // For local/asset JSON
  factory Song.fromAssetMap(Map<String, dynamic> m) => Song(
    id: (m['id'] ?? '').toString(),
    title: (m['title'] ?? '').toString(),
    artist: (m['artist'] ?? '').toString(),
    album: m['album']?.toString(),
    assetAudio: m['assetAudio']?.toString(),
    assetImage: m['assetImage']?.toString(),
  );

  // For remote/Firebase JSON (optional, if you later go back to Firebase)

}
