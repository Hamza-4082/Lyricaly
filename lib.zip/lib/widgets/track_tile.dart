import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../models/song.dart';
import '../providers/player_provider.dart';
import '../providers/favourites_provider.dart';
import '../screens/player_screen.dart';

class TrackTile extends StatelessWidget {
  final Song song;
  final VoidCallback? onTapOverride; // <-- new (optional)

  const TrackTile({super.key, required this.song, this.onTapOverride});

  @override
  Widget build(BuildContext context) {
    final favs = context.watch<FavouritesProvider>();
    final isFav = favs.isFav(song.id);

    return ListTile(
      tileColor: const Color(0xFF1F1F1F),
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(8)),
      leading: Container(
        width: 48,
        height: 48,
        decoration: BoxDecoration(
          color: Colors.white10,
          borderRadius: BorderRadius.circular(6),
        ),
      ),
      title: Text(song.title, maxLines: 1, overflow: TextOverflow.ellipsis),
      subtitle: Text(
        song.artist,
        maxLines: 1,
        overflow: TextOverflow.ellipsis,
        style: const TextStyle(color: Colors.white70),
      ),
      trailing: PopupMenuButton<String>(
        icon: const Icon(Icons.more_vert),
        onSelected: (value) async {
          if (value == 'fav') {
            await context.read<FavouritesProvider>().toggle(song.id);
            final added = context.read<FavouritesProvider>().isFav(song.id);
            if (context.mounted) {
              ScaffoldMessenger.of(context).showSnackBar(
                SnackBar(content: Text(added
                    ? 'Added to favourites'
                    : 'Removed from favourites')),
              );
            }
          }
        },
        itemBuilder: (context) => [
          PopupMenuItem<String>(
            value: 'fav',
            child: Row(
              children: [
                Icon(isFav ? Icons.favorite : Icons.favorite_border, size: 20),
                const SizedBox(width: 8),
                Text(isFav ? 'Remove from favourites' : 'Add to favourites'),
              ],
            ),
          ),
        ],
      ),
      onTap: onTapOverride ??
              () {
            context.read<PlayerProvider>().setSong(song);
            Navigator.push(
              context,
              MaterialPageRoute(builder: (_) => PlayerScreen(song: song)),
            );
          },
    );
  }
}
