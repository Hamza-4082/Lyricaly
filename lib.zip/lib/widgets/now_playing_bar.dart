// lib/widgets/now_playing_bar.dart
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../providers/player_provider.dart';
import '../screens/player_screen.dart';

class NowPlayingBar extends StatelessWidget {
  const NowPlayingBar({super.key});

  @override
  Widget build(BuildContext context) {
    final p = context.watch<PlayerProvider>();
    final s = p.current;

    void _openPlayer() {
      if (s == null) return;
      Navigator.push(
        context,
        MaterialPageRoute(builder: (_) => PlayerScreen(song: s)),
      );
    }

    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
      decoration: const BoxDecoration(
        color: Color(0xFF181818),
        border: Border(top: BorderSide(color: Colors.white10)),
      ),
      child: Row(
        children: [
          // Artwork/thumbnail area (also opens player)
          GestureDetector(
            onTap: _openPlayer,
            behavior: HitTestBehavior.opaque,
            child: Container(
              width: 36,
              height: 36,
              decoration: BoxDecoration(
                color: Colors.white10,
                borderRadius: BorderRadius.circular(4),
              ),
            ),
          ),
          const SizedBox(width: 12),

          // Title/artist (tap to open player)
          Expanded(
            child: GestureDetector(
              onTap: _openPlayer,
              behavior: HitTestBehavior.opaque,
              child: Text(
                s?.title ?? 'Nothing playing',
                maxLines: 1,
                overflow: TextOverflow.ellipsis,
                style: const TextStyle(color: Colors.white70),
              ),
            ),
          ),

          // Transport controls
          IconButton(
            icon: const Icon(Icons.skip_previous_rounded),
            onPressed: s == null ? null : () => context.read<PlayerProvider>().previous(),
            tooltip: 'Previous',
          ),
          IconButton(
            icon: Icon(p.isPlaying ? Icons.pause : Icons.play_arrow_rounded),
            onPressed: s == null ? null : () => context.read<PlayerProvider>().togglePlayPause(),
            tooltip: p.isPlaying ? 'Pause' : 'Play',
          ),
          IconButton(
            icon: const Icon(Icons.skip_next_rounded),
            onPressed: s == null ? null : () => context.read<PlayerProvider>().next(),
            tooltip: 'Next',
          ),
        ],
      ),
    );
  }
}
