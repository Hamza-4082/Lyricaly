import 'package:flutter/material.dart';
import '../models/song.dart';

class PlaylistCard extends StatelessWidget {
  final String title;
  final List<Song> songs;
  final VoidCallback onTap;

  const PlaylistCard({
    super.key,
    required this.title,
    required this.songs,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    // Try to show the first song's artwork if available
    Widget art;
    final cover = songs.isNotEmpty ? songs.first : null;
    if (cover?.assetImage != null && cover!.assetImage!.isNotEmpty) {
      art = Image.asset(cover.assetImage!, fit: BoxFit.cover);
    } else if (cover?.imageUrl != null && cover!.imageUrl!.isNotEmpty) {
      art = Image.network(cover.imageUrl!, fit: BoxFit.cover);
    } else {
      art = Container(color: const Color(0xFF2A2A2A));
    }

    return InkWell(
      onTap: onTap,
      borderRadius: BorderRadius.circular(12),
      child: Container(
        width: 160,
        decoration: BoxDecoration(
          color: const Color(0xFF1F1F1F),
          borderRadius: BorderRadius.circular(12),
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            AspectRatio(
              aspectRatio: 1,
              child: ClipRRect(
                borderRadius: const BorderRadius.vertical(top: Radius.circular(12)),
                child: art,
              ),
            ),
            Padding(
              padding: const EdgeInsets.all(10),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(title,
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                      style: const TextStyle(fontWeight: FontWeight.w700)),
                  const SizedBox(height: 4),
                  Text('${songs.length} tracks',
                      style: const TextStyle(color: Colors.white70, fontSize: 12)),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}
