import 'package:flutter/material.dart'; import 'package:google_fonts/google_fonts.dart';
class AppTheme{ static const Color spotifyGreen=Color(0xFF1DB954);
  static ThemeData dark(){ final base=ThemeData.dark(useMaterial3:true); const surface=Color(0xFF121212), surface2=Color(0xFF181818);
    return base.copyWith(scaffoldBackgroundColor: surface, appBarTheme: const AppBarTheme(backgroundColor: surface, foregroundColor: Colors.white),
      bottomNavigationBarTheme: const BottomNavigationBarThemeData(backgroundColor: surface2, selectedItemColor: spotifyGreen, unselectedItemColor: Colors.white70),
      textTheme: GoogleFonts.interTextTheme(base.textTheme).apply(bodyColor: Colors.white, displayColor: Colors.white), cardColor: surface2, dividerColor: Colors.white12);
  }}
