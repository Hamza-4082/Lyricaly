import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../providers/music_provider.dart';
import '../providers/favourites_provider.dart';
import '../widgets/section_header.dart';
import '../widgets/track_tile.dart';
import '../widgets/playlist_card.dart';
import 'mix_screen.dart';
import '../models/song.dart';


class HomeScreen extends StatelessWidget {
  const HomeScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final music = context.watch<MusicProvider>();
    final songs = music.songs;

    // Compute mixes
    final favIds = context.watch<FavouritesProvider>().ids;
    final favSongs = songs.where((s) => favIds.contains(s.id)).toList();

    // Top artist among favourites (fallback to first artist in all songs)
    String? topArtist;
    if (favSongs.isNotEmpty) {
      final counts = <String, int>{};
      for (final s in favSongs) {
        counts[s.artist] = (counts[s.artist] ?? 0) + 1;
      }
      topArtist = counts.entries.reduce((a, b) => a.value >= b.value ? a : b).key;
    } else if (songs.isNotEmpty) {
      topArtist = songs.first.artist;
    }
    final topArtistMix = (topArtist == null)
        ? <Song>[]
        : songs.where((s) => s.artist == topArtist).toList();

    // Quick Mix: small random sample
    final quickMix = List<Song>.from(songs);
    quickMix.shuffle();
    if (quickMix.length > 10) quickMix.removeRange(10, quickMix.length);

    return CustomScrollView(
      slivers: [
        const SliverAppBar(pinned: true, title: Text('Good evening')),
        SliverToBoxAdapter(
          child: Padding(
            padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const SectionHeader(title: 'Recently played'),
                const SizedBox(height: 8),
                if (songs.isEmpty)
                  const Text('No songs yet.', style: TextStyle(color: Colors.white70))
                else
                  ListView.separated(
                    itemCount: songs.length,
                    shrinkWrap: true,
                    physics: const NeverScrollableScrollPhysics(),
                    separatorBuilder: (_, __) => const SizedBox(height: 6),
                    itemBuilder: (ctx, i) => TrackTile(song: songs[i]),
                  ),
                const SizedBox(height: 16),

                const SectionHeader(title: 'Made for you'),
                const SizedBox(height: 8),
                SizedBox(
                  height: 220,
                  child: ListView(
                    scrollDirection: Axis.horizontal,
                    children: [
                      if (favSongs.isNotEmpty)
                        Padding(
                          padding: const EdgeInsets.only(right: 12),
                          child: PlaylistCard(
                            title: 'Your Favourites',
                            songs: favSongs,
                            onTap: () {
                              Navigator.push(
                                context,
                                MaterialPageRoute(
                                  builder: (_) => MixScreen(
                                    title: 'Your Favourites',
                                    songs: favSongs,
                                  ),
                                ),
                              );
                            },
                          ),
                        ),
                      if (topArtistMix.isNotEmpty)
                        Padding(
                          padding: const EdgeInsets.only(right: 12),
                          child: PlaylistCard(
                            title: 'Top Artist: $topArtist',
                            songs: topArtistMix,
                            onTap: () {
                              Navigator.push(
                                context,
                                MaterialPageRoute(
                                  builder: (_) => MixScreen(
                                    title: 'Top Artist: $topArtist',
                                    songs: topArtistMix,
                                  ),
                                ),
                              );
                            },
                          ),
                        ),
                      if (quickMix.isNotEmpty)
                        Padding(
                          padding: const EdgeInsets.only(right: 12),
                          child: PlaylistCard(
                            title: 'Quick Mix',
                            songs: quickMix,
                            onTap: () {
                              Navigator.push(
                                context,
                                MaterialPageRoute(
                                  builder: (_) => MixScreen(
                                    title: 'Quick Mix',
                                    songs: quickMix,
                                  ),
                                ),
                              );
                            },
                          ),
                        ),
                      if (favSongs.isEmpty && topArtistMix.isEmpty && quickMix.isEmpty)
                        const Center(child: Text('No recommendations yet')),
                    ],
                  ),
                ),
                const SizedBox(height: 24),
              ],
            ),
          ),
        )
      ],
    );
  }
}
