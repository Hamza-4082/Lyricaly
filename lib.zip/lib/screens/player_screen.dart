import 'dart:math' as math;
import 'package:flutter/material.dart';
import 'package:just_audio/just_audio.dart';
import 'package:provider/provider.dart';
import '../models/song.dart';
import '../providers/player_provider.dart';

class PlayerScreen extends StatefulWidget {
  final Song song;
  const PlayerScreen({super.key, required this.song});

  @override
  State<PlayerScreen> createState() => _PlayerScreenState();
}

class _PlayerScreenState extends State<PlayerScreen> {
  double? _dragValue;

  @override
  void initState() {
    super.initState();
    Future.microtask(() {
      final p = context.read<PlayerProvider>();
      if (p.current == null || p.current!.id != widget.song.id) {
        // Only set if we’re not already on this song (preserves a queue loaded by MixScreen)
        p.setSong(widget.song);
      }
    });
  }



  @override
  Widget build(BuildContext context) {
    final p = context.watch<PlayerProvider>();
    final s = p.current ?? widget.song;

    Widget art() {
      if (s.assetImage != null && s.assetImage!.isNotEmpty) {
        return Image.asset(s.assetImage!, fit: BoxFit.cover);
      }
      if (s.imageUrl != null && s.imageUrl!.isNotEmpty) {
        return Image.network(s.imageUrl!, fit: BoxFit.cover);
      }
      return Container(color: const Color(0xFF1F1F1F));
    }

    Color active(Color c) => c; // you can theme this
    const green = Color(0xFF1DB954);

    return Scaffold(
      appBar: AppBar(
        leading: IconButton(
          icon: const Icon(Icons.keyboard_arrow_down_rounded),
          onPressed: () => Navigator.pop(context),
        ),
      ),
      body: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          children: [
            Expanded(
              child: Center(
                child: AspectRatio(
                  aspectRatio: 1,
                  child: ClipRRect(
                    borderRadius: BorderRadius.circular(16),
                    child: art(),
                  ),
                ),
              ),
            ),
            const SizedBox(height: 16),
            Text(s.title, style: const TextStyle(fontSize: 22, fontWeight: FontWeight.w700)),
            const SizedBox(height: 4),
            Text(s.artist, style: const TextStyle(color: Colors.white70)),
            const SizedBox(height: 16),

            // position / duration / seeking
            StreamBuilder<Duration?>(
              stream: p.durationStream,
              builder: (context, durSnap) {
                final total = durSnap.data ?? Duration.zero;
                final totalMs = total.inMilliseconds.toDouble();
                final double max = math.max(1.0, totalMs);

                return StreamBuilder<Duration>(
                  stream: p.positionStream,
                  builder: (context, posSnap) {
                    final posMs = (posSnap.data ?? Duration.zero).inMilliseconds.toDouble();
                    final value = (_dragValue ?? posMs).clamp(0.0, max);

                    return Column(
                      children: [
                        Slider(
                          value: value,
                          max: max,
                          onChanged: (v) => setState(() => _dragValue = v),
                          onChangeEnd: (v) async {
                            setState(() => _dragValue = null);
                            await context.read<PlayerProvider>()
                                .seek(Duration(milliseconds: v.round()));
                          },
                        ),
                        Row(
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: [
                            Text(_fmt(Duration(milliseconds: value.round())), style: const TextStyle(color: Colors.white70)),
                            Text(_fmt(Duration(milliseconds: max.round())), style: const TextStyle(color: Colors.white70)),
                          ],
                        ),
                      ],
                    );
                  },
                );
              },
            ),

            const SizedBox(height: 12),
            Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                IconButton(
                  icon: Icon(Icons.shuffle, color: p.shuffle ? green : null),
                  onPressed: () => context.read<PlayerProvider>().toggleShuffle(),
                ),
                const SizedBox(width: 8),
                IconButton(
                  icon: const Icon(Icons.skip_previous_rounded, size: 36),
                  onPressed: () => context.read<PlayerProvider>().previous(),
                ),
                const SizedBox(width: 8),
                ElevatedButton(
                  onPressed: () => context.read<PlayerProvider>().togglePlayPause(),
                  style: ElevatedButton.styleFrom(
                    backgroundColor: Colors.white,
                    foregroundColor: Colors.black,
                    shape: const CircleBorder(),
                    padding: const EdgeInsets.all(10),
                  ),
                  child: Icon(p.isPlaying ? Icons.pause : Icons.play_arrow_rounded, size: 36),
                ),
                const SizedBox(width: 8),
                IconButton(
                  icon: const Icon(Icons.skip_next_rounded, size: 36),
                  onPressed: () => context.read<PlayerProvider>().next(),
                ),
                const SizedBox(width: 8),
                IconButton(
                  icon: Icon(
                    p.loop == LoopMode.one ? Icons.repeat_one : Icons.repeat,
                    color: p.loop == LoopMode.off ? null : green,
                  ),
                  onPressed: () => context.read<PlayerProvider>().cycleRepeat(),
                ),
              ],
            ),
            const SizedBox(height: 16),
          ],
        ),
      ),
    );
  }

  String _fmt(Duration d) {
    final m = d.inMinutes.remainder(60).toString();
    final s = d.inSeconds.remainder(60).toString().padLeft(2, '0');
    return '$m:$s';
  }
}
