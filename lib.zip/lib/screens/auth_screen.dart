import 'package:flutter/material.dart'; import 'package:provider/provider.dart'; import '../providers/auth_provider.dart'; import 'shell_screen.dart';
class AuthScreen extends StatefulWidget{ const AuthScreen({super.key}); @override State<AuthScreen> createState()=>_S(); }
class _S extends State<AuthScreen>{ final _email=TextEditingController(), _pass=TextEditingController(); bool _isLogin=true, _loading=false; @override void dispose(){_email.dispose(); _pass.dispose(); super.dispose();}
  Future<void> _submit() async{ if(_email.text.isEmpty || _pass.text.length<6){ ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Enter valid email & 6+ char password'))); return; }
    setState(()=>_loading=true); try{ final a=context.read<AuthProvider>(); if(_isLogin){ await a.login(_email.text.trim(), _pass.text.trim()); } else { await a.signup(_email.text.trim(), _pass.text.trim()); }
      if(!mounted) return; Navigator.of(context).pushReplacement(MaterialPageRoute(builder: (_)=>const ShellScreen())); } catch(e){ ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(e.toString()))); }
    finally{ if(mounted) setState(()=>_loading=false);} }
  @override Widget build(BuildContext c)=>Scaffold(appBar: AppBar(title: const Text('Lyrically Login')), body: Padding(padding: const EdgeInsets.all(16), child: Column(children:[
    TextField(controller:_email, decoration: const InputDecoration(labelText:'Email')), const SizedBox(height:8),
    TextField(controller:_pass, obscureText:true, decoration: const InputDecoration(labelText:'Password')), const SizedBox(height:16),
    ElevatedButton(onPressed:_loading?null:_submit, child: Text(_isLogin?'Login':'Sign up')),
    TextButton(onPressed: ()=>setState(()=>_isLogin=!_isLogin), child: Text(_isLogin?'Create account':'I have an account')), ]))); }
