import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../providers/favourites_provider.dart';
import '../providers/music_provider.dart';
import '../widgets/track_tile.dart';

class FavouritesScreen extends StatelessWidget {
  const FavouritesScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final favs = context.watch<FavouritesProvider>();
    final songs = context
        .watch<MusicProvider>()
        .songs
        .where((s) => favs.isFav(s.id))
        .toList();

    return Scaffold(
      appBar: AppBar(title: const Text('Favourites')),
      body: songs.isEmpty
          ? const Center(child: Text('No favourites yet'))
          : ListView.separated(
        padding: const EdgeInsets.all(16),
        itemCount: songs.length,
        separatorBuilder: (_, __) => const SizedBox(height: 6),
        itemBuilder: (_, i) => TrackTile(song: songs[i]),
      ),
    );
  }
}
