import 'dart:math';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../models/song.dart';
import '../providers/player_provider.dart';
import '../widgets/track_tile.dart';
import 'player_screen.dart';

class MixScreen extends StatelessWidget {
  final String title;
  final List<Song> songs;
  const MixScreen({super.key, required this.title, required this.songs});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(title),
        actions: [
          // Shuffle Play action
          IconButton(
            icon: const Icon(Icons.shuffle),
            onPressed: () async {
              if (songs.isEmpty) return;
              final start = Random().nextInt(songs.length);
              final p = context.read<PlayerProvider>();
              p.shuffle = true; // enable shuffle
              await p.loadQueue(songs, startIndex: start, autoplay: true);
              if (context.mounted) {
                Navigator.push(
                  context,
                  MaterialPageRoute(builder: (_) => PlayerScreen(song: songs[start])),
                );
              }
            },
          ),
        ],
      ),
      body: songs.isEmpty
          ? const Center(child: Text('No tracks here yet'))
          : ListView.separated(
        padding: const EdgeInsets.all(16),
        itemCount: songs.length,
        separatorBuilder: (_, __) => const SizedBox(height: 6),
        itemBuilder: (_, i) => TrackTile(
          song: songs[i],
          onTapOverride: () async {
            final p = context.read<PlayerProvider>();
            await p.loadQueue(songs, startIndex: i, autoplay: true);
            if (context.mounted) {
              Navigator.push(
                context,
                MaterialPageRoute(builder: (_) => PlayerScreen(song: songs[i])),
              );
            }
          },
        ),
      ),
    );
  }
}
