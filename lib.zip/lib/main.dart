import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:audio_session/audio_session.dart';
import 'theme/app_theme.dart';
import 'screens/auth_screen.dart';
import 'screens/shell_screen.dart';
import 'providers/auth_provider.dart';
import 'providers/music_provider.dart';
import 'providers/player_provider.dart';
import 'providers/favourites_provider.dart';


void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  final session = await AudioSession.instance;
  await session.configure(const AudioSessionConfiguration.music());
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext c) => MultiProvider(
          providers: [
            ChangeNotifierProvider(create: (_) => AuthProvider()),
            ChangeNotifierProvider(create: (_) => MusicProvider()),
            ChangeNotifierProvider(create: (_) => PlayerProvider()),
            ChangeNotifierProvider(
              create: (_) {
                final p = FavouritesProvider();
                p.load(); // hydrate from SharedPreferences
                return p;
              },
            ),
          ],
          child: MaterialApp(
              title: 'Lyrically',
              theme: AppTheme.dark(),
              debugShowCheckedModeBanner: false,
              home: const AuthScreen()));
}
