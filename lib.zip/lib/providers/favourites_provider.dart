import 'package:flutter/foundation.dart';
import 'package:shared_preferences/shared_preferences.dart';

class FavouritesProvider extends ChangeNotifier {
  static const _key = 'favourites_ids';
  final Set<String> _ids = {};

  Set<String> get ids => _ids;

  Future<void> load() async {
    final sp = await SharedPreferences.getInstance();
    final list = sp.getStringList(_key) ?? const [];
    _ids..clear()..addAll(list);
    notifyListeners();
  }

  Future<void> _save() async {
    final sp = await SharedPreferences.getInstance();
    await sp.setStringList(_key, _ids.toList());
  }

  bool isFav(String id) => _ids.contains(id);

  Future<void> toggle(String id) async {
    if (_ids.contains(id)) {
      _ids.remove(id);
    } else {
      _ids.add(id);
    }
    await _save();
    notifyListeners();
  }

  Future<void> remove(String id) async {
    _ids.remove(id);
    await _save();
    notifyListeners();
  }
}
