import 'dart:math';
import 'package:flutter/foundation.dart';
import 'package:just_audio/just_audio.dart';
import '../models/song.dart';

class PlayerProvider extends ChangeNotifier {
  final _player = AudioPlayer();

  Song? current;
  List<Song> _queue = [];
  int _index = -1;

  // Keep history so Previous works correctly in shuffle mode
  final List<int> _history = [];

  bool shuffle = false;
  LoopMode loop = LoopMode.off; // off, one, all

  // Expose streams/state
  Stream<PlayerState> get stateStream => _player.playerStateStream;
  Stream<Duration?> get durationStream => _player.durationStream;
  Stream<Duration> get positionStream => _player.positionStream;
  bool get isPlaying => _player.playing;

  // Helpers
  int get queueLength => _queue.length;
  bool get hasQueue => _queue.length > 1;

  /// Load a list as the active queue and start at [startIndex].
  Future<void> loadQueue(List<Song> songs,
      {int startIndex = 0, bool autoplay = true}) async {
    if (songs.isEmpty) return;
    _queue = List<Song>.from(songs);
    _index = startIndex.clamp(0, _queue.length - 1);
    _history.clear();
    await _setCurrent(_queue[_index], autoplay: autoplay);
  }

  /// Play a specific song (outside of a queue).
  Future<void> setSong(Song s) async {
    _queue = [s];
    _index = 0;
    _history.clear();
    await _setCurrent(s, autoplay: true);
  }

  Future<void> _setCurrent(Song s, {bool autoplay = true}) async {
    current = s;
    if (s.assetAudio != null && s.assetAudio!.isNotEmpty) {
      await _player.setAsset(s.assetAudio!);
    } else if (s.filePath != null && s.filePath!.isNotEmpty) {
      await _player.setFilePath(s.filePath!);
    } else if (s.audioUrl != null && s.audioUrl!.isNotEmpty) {
      await _player.setUrl(s.audioUrl!);
    } else {
      throw Exception('No audio source for ${s.title}');
    }
    await _player.setLoopMode(loop);
    if (autoplay) await _player.play();
    notifyListeners();
  }

  Future<void> togglePlayPause() async {
    if (_player.playing) {
      await _player.pause();
    } else {
      await _player.play();
    }
    notifyListeners();
  }

  Future<void> next() async {
    if (_queue.isEmpty) return;

    if (loop == LoopMode.one) {
      await _player.seek(Duration.zero);
      await _player.play();
      return;
    }

    if (shuffle && _queue.length > 1) {
      // remember where we were so Previous can come back here
      _history.add(_index);
      final rng = Random();
      int nextIdx;
      do {
        nextIdx = rng.nextInt(_queue.length);
      } while (nextIdx == _index);
      _index = nextIdx;
    } else {
      _index = (_index + 1) % _queue.length;
    }
    await _setCurrent(_queue[_index], autoplay: true);
  }

  Future<void> previous() async {
    if (_queue.isEmpty) return;

    if (loop == LoopMode.one) {
      await _player.seek(Duration.zero);
      await _player.play();
      return;
    }

    if (shuffle && _history.isNotEmpty) {
      // go back to the last played index
      _index = _history.removeLast();
    } else {
      _index = (_index - 1) % _queue.length;
      if (_index < 0) _index = _queue.length - 1;
    }
    await _setCurrent(_queue[_index], autoplay: true);
  }

  void toggleShuffle() {
    shuffle = !shuffle;
    notifyListeners();
  }

  void cycleRepeat() {
    switch (loop) {
      case LoopMode.off:
        loop = LoopMode.one;
        break;
      case LoopMode.one:
        loop = LoopMode.all;
        break;
      case LoopMode.all:
        loop = LoopMode.off;
        break;
    }
    _player.setLoopMode(loop);
    notifyListeners();
  }

  Future<void> seek(Duration position) async {
    await _player.seek(position);
  }

  @override
  void dispose() {
    _player.dispose();
    super.dispose();
  }
}
