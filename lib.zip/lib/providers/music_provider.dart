import 'dart:convert';
import 'package:flutter/foundation.dart';
import 'package:flutter/services.dart' show rootBundle;
import '../models/song.dart';

class MusicProvider extends ChangeNotifier {
  final List<Song> _songs = [];
  bool isLoading = false;

  List<Song> get songs => List.unmodifiable(_songs);

  /// Load songs from assets/data/songs.json
  Future<void> loadFromAssets() async {
    isLoading = true;
    notifyListeners();

    final raw = await rootBundle.loadString('assets/data/songs.json');
    final data = json.decode(raw) as Map<String, dynamic>;
    final list = (data['songs'] as List).cast<Map<String, dynamic>>();

    _songs
      ..clear()
      ..addAll(list.map(Song.fromAssetMap));

    isLoading = false;
    notifyListeners();
  }

  List<Song> searchLocal(String q) {
    final query = q.trim().toLowerCase();
    if (query.isEmpty) return songs;
    return _songs.where((s) =>
    s.title.toLowerCase().contains(query) ||
        s.artist.toLowerCase().contains(query)).toList();
  }
}
