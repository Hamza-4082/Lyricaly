import 'dart:convert';
import 'package:flutter/foundation.dart';
import 'package:http/http.dart' as http;
import 'package:shared_preferences/shared_preferences.dart';
import '../firebase_rest_config.dart';
class AuthProvider extends ChangeNotifier{
  String? _token,_userId,_role; String? get token=>_token; String? get userRole=>_role; bool get isAuth=>_token!=null;
  Future<void> login(String email,String password) async{
    final url=Uri.parse('https://identitytoolkit.googleapis.com/v1/accounts:signInWithPassword?key='+apiKey);
    final res=await http.post(url,body: json.encode({'email':email,'password':password,'returnSecureToken':true}));
    final d=json.decode(res.body); if(res.statusCode>=400) throw Exception(d['error']?['message']??'Login failed');
    _token=d['idToken']; _userId=d['localId']; await _loadRole(); await _persist(); notifyListeners();
  }
  Future<void> signup(String email,String password) async{
    final url=Uri.parse('https://identitytoolkit.googleapis.com/v1/accounts:signUp?key='+apiKey);
    final res=await http.post(url,body: json.encode({'email':email,'password':password,'returnSecureToken':true}));
    final d=json.decode(res.body); if(res.statusCode>=400) throw Exception(d['error']?['message']??'Signup failed');
    _token=d['idToken']; _userId=d['localId']; await _persist(); notifyListeners();
  }
  Future<void> _loadRole() async{ if(_token==null||_userId==null) return; final url=Uri.parse('$databaseURL/users/'+_userId!+'/role.json?auth='+_token!); final res=await http.get(url); if(res.statusCode==200) _role=json.decode(res.body); }
  Future<void> _persist() async{ final sp=await SharedPreferences.getInstance(); await sp.setString('auth', json.encode({'token':_token,'userId':_userId,'role':_role})); }
}
